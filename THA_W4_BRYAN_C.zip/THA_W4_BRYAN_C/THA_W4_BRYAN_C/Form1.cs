﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace THA_W4_BRYAN_C
{
    public partial class Form1 : Form
    {
        List<string> countrylist = new List<string>();
        List<string> teamlist = new List<string>();
        List<string> playerlist = new List<string>();
        Dictionary<string, List<string>> teamsByCountry = new Dictionary<string, List<string>>();
        Dictionary<string, List<string>> playersByTeam = new Dictionary<string, List<string>>();

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            cmbPlayerPosition.Items.Add("GK");
            cmbPlayerPosition.Items.Add("DF");
            cmbPlayerPosition.Items.Add("MF");
            cmbPlayerPosition.Items.Add("FW");

            cmbChooseCountry.Items.Add("England");
            cmbChooseCountry.Items.Add("Arab Saudi");


        }

        private void cmbChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxTeams.Items.Clear();
            cmbChooseTeam.Items.Clear();
            cmbChooseTeam.Text = "";
            if (cmbChooseCountry.Text == "England")
            {
                if (!cmbChooseTeam.Items.Contains("England"))
                {
                    cmbChooseTeam.Items.Add("Arsenal");
                    cmbChooseTeam.Items.Add("Manchester United");
                }
            }

            if (cmbChooseCountry.Text == "Arab Saudi")
            {
                if (!cmbChooseTeam.Items.Contains("Arab Saudi"))
                {
                    cmbChooseTeam.Items.Add("Al-Nassr");
                }
            }

            string selectedCountry = cmbChooseCountry.SelectedItem.ToString();
            if (!teamsByCountry.ContainsKey(selectedCountry))
            {
                teamsByCountry.Add(selectedCountry, new List<string>());
            }
            List<string> teams = teamsByCountry[selectedCountry];

            foreach (string team in teams)
            {
                cmbChooseTeam.Items.Add(team);
            }
            cmbChooseTeam.SelectedIndex = 0;

        }



        private void btnAdd1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TBTeamName.Text) && !string.IsNullOrEmpty(TBTeamCity.Text) && !string.IsNullOrEmpty(TBTeamCountry.Text))
            {
                Team tim = new Team();
                tim.TeamName = TBTeamName.Text;
                tim.TeamCity = TBTeamCity.Text;
                tim.TeamCountry = TBTeamCountry.Text;

                if (playersByTeam.ContainsKey(tim.TeamCountry + tim.TeamName))
                {
                    MessageBox.Show("Team already exists.");
                    TBTeamName.Text = "";
                    TBTeamCity.Text = "";
                    TBTeamCountry.Text = "";
                    return;
                }
                if (!playersByTeam.ContainsKey(tim.TeamCountry + tim.TeamName))
                {
                    if (teamsByCountry.ContainsKey(tim.TeamCountry))
                    {
                        teamsByCountry[tim.TeamCountry].Add(tim.TeamName);
                    }
                    else
                    {
                        teamsByCountry.Add(tim.TeamCountry, new List<string> { tim.TeamName });

                        cmbChooseCountry.Items.Add(tim.TeamCountry);
                    }
                    playersByTeam.Add(tim.TeamCountry + tim.TeamName, new List<string>());
                    cmbChooseTeam.Items.Add(tim.TeamName);
                }
            }
            else
            {
                MessageBox.Show("Fill the box!" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            TBTeamName.Text = "";
            TBTeamCity.Text = "";
            TBTeamCountry.Text = "";
            cmbChooseTeam.Text = "";
            cmbChooseCountry.Text = "";
        }

        private void btnAdd2_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(TBPlayerName.Text) && !string.IsNullOrEmpty(TBPlayerNumber.Text))
            {
                List<string> playerNames = new List<string>();
                foreach (object item in listBoxTeams.Items)
                {
                    string playerName = item.ToString().Split(' ')[1];
                    playerNames.Add(playerName);
                }

                if (playerNames.Contains(TBPlayerName.Text))
                {
                    MessageBox.Show("Player name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TBPlayerName.Text = "";
                    TBPlayerNumber.Text = "";
                    cmbPlayerPosition.Text = "";
                    return;
                }
                else
                {
                    Team team = new Team();
                    Player player = new Player();
                    player.PlayerName = TBPlayerName.Text;
                    player.PlayerNum = TBPlayerNumber.Text;
                    player.PlayerPos = cmbPlayerPosition.SelectedItem.ToString();
                    team.TeamName = cmbChooseTeam.Text;

                    if (!playerlist.Contains($"({player.PlayerNum}) {player.PlayerName}, {player.PlayerPos}+{team.TeamName}"))
                    {
                        playerlist.Add($"({player.PlayerNum}) {player.PlayerName}, {player.PlayerPos}+{team.TeamName}");
                        cmbChooseTeam_SelectedIndexChanged(sender, new EventArgs());
                    }
                    else
                    {
                        MessageBox.Show("Player Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fill the box!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            TBPlayerName.Text = "";
            TBPlayerNumber.Text = "";
            cmbPlayerPosition.Text = "";
        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            if (listBoxTeams.Items.Count <= 11)
            {
                MessageBox.Show("Player Must not be Less Than 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int index = listBoxTeams.SelectedIndex;
                string removePlayer = listBoxTeams.SelectedItem.ToString();
                listBoxTeams.Items.RemoveAt(index);
                playerlist.Remove(removePlayer);
            }
        }

        private void cmbChooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {

            listBoxTeams.Items.Clear();

            string selectedteamname = cmbChooseTeam.SelectedItem.ToString();
            int count = 0;

        BACK:
            if (playerlist.Count != 0)
            {
                foreach (string player in playerlist)
                {
                    string[] addedplayer = player.Split('+');
                    if (addedplayer[1] == selectedteamname)
                    {
                        listBoxTeams.Items.Add(addedplayer[0]);
                        count++;
                    }
                }
            }


                 switch (cmbChooseTeam.Text)
            {
                case "Arsenal":
                    if (count == 0)
                    {
                        playerlist.Add("(01) Bernd Leno, GK+Arsenal");
                        playerlist.Add("(03) Kieran Tierney, DF+Arsenal");
                        playerlist.Add("(06) Gabriel Magalhães, DF+Arsenal");
                        playerlist.Add("(04) Ben White, DF+Arsenal");
                        playerlist.Add("(02) Héctor Bellerín, DF+Arsenal");
                        playerlist.Add("(18) Thomas Partey, MF+Arsenal");
                        playerlist.Add("(34) Granit Xhaka, FW+Arsenal");
                        playerlist.Add("(8) Martin Ødegaard, FW+Arsenal");
                        playerlist.Add("(7) Bukayo Saka, DF+Arsenal");
                        playerlist.Add("(14) Christian Eriksen, MF+Arsenal");
                        playerlist.Add("(19) Casemiro, MF+Arsenal");
                        goto BACK;
                    }
                    break;

                case "Manchester United":
                    if (count == 0)
                    {
                        playerlist.Add("(01) David De Gea, GK+Manchester United");
                        playerlist.Add("(23) Luke Shaw, DF+Manchester United");
                        playerlist.Add("(29) Aaron Wan-Bissaka, DF+Manchester United");
                        playerlist.Add("(05) Harry Maguire, DF+Manchester United");
                        playerlist.Add("(17) Fred, MF+Manchester United");
                        playerlist.Add("(06) Paul Pogba, MF+Manchester United");
                        playerlist.Add("(18) Bruno Fernandes, MF+Manchester United");
                        playerlist.Add("(10) Marcus Rashford, FW+Manchester United");
                        playerlist.Add("(07) Edinson Cavani, FW+Manchester United");
                        playerlist.Add("(11) Mason Greenwood, FW+Manchester United");
                        playerlist.Add("(25) Jadon Sancho, FW+Manchester United");
                        goto BACK;
                    }
                    break;

                case "Al-Nassr":
                    if (count == 0)
                    {
                        playerlist.Add("(01) Brad Jones, GK+Al-Nassr");
                        playerlist.Add("(02) Sultan Al-Ghannam, DF+Al-Nassr");
                        playerlist.Add("(03) Abdulrahman Al-Obaid, DF+Al-Nassr");
                        playerlist.Add("(13) Abdullah Madu, DF+Al-Nassr");
                        playerlist.Add("(33) Maicon, DF+Al-Nassr");
                        playerlist.Add("(04) Abdulfattah Asiri, MF+Al-Nassr");
                        playerlist.Add("(14) Nordin Amrabat, MF+Al-Nassr");
                        playerlist.Add("(15) Abdulmajeed Al-Sulaiheem, MF+Al-Nassr");
                        playerlist.Add("(08) Petros, MF+Al-Nassr");
                        playerlist.Add("(11) Firas Al-Buraikan, FW+Al-Nassr");
                        playerlist.Add("(09) Abderrazak Hamdallah, FW+Al-Nassr");
                        playerlist.Add("(07) Cristiano Ronaldo, FW+Al-Nassr");
                        goto BACK;
                    }
                    break;
            }
        }
             class Team
        {
            private string teamName;
            public string TeamName
            {
                get { return teamName; }
                set { teamName = value; }
            }
            private string teamCountry;
            public string TeamCountry
            {
                get { return teamCountry; }
                set { teamCountry = value; }
            }
            private string teamCity;
            public string TeamCity
            {
                get { return teamCity; }
                set { teamCity = value; }
            }

            public List<Player> Players = new List<Player>();
        }

        class Player
        {
            private string playerName;
            public string PlayerName
            {
                get { return playerName; }
                set { playerName = value; }
            }

            private string playerNum;
            public string PlayerNum
            {
                get { return playerNum; }
                set { playerNum = value; }
            }

            private string playerPos;
            public string PlayerPos
            {
                get { return playerPos; }
                set { playerPos = value; }
            }

         

        }


    }
}
